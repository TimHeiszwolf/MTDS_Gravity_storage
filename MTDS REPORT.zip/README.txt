This is the LaTeX template for the technical report of EST2020.

